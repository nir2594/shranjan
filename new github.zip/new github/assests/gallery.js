// assets/js/gallery.js

window.openLightbox = (img) => {
  lightbox.style.display = "block";
  lightboxImg.src = img.src;
};

window.closeLightbox = (e) => {
  if (e.target.id === "lightbox") {
    lightbox.style.display = "none";
  }
};
