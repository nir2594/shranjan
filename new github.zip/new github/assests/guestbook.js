// assets/js/guestbook.js

window.submitWishToDB = async () => {
  const name = guestName.value;
  const relationship = relationshipSelect.value;
  const text = finalWishInput.value;

  if (!name || !text) {
    alert("Please fill name and message");
    return;
  }

  const ok = await window.saveWishToFirestore(name, relationship, text);
  if (ok) alert("Thank you! Your wish is saved.");
};

window.openLogModal = () => {
  logModal.style.display = "flex";
  logContent.innerHTML = "";

  window.wishPool.forEach(w => {
    logContent.innerHTML += `
      <div class="log-entry">
        <strong>${w.name}</strong>
        <p>"${w.text}"</p>
      </div>`;
  });
};

window.closeLogModal = () => {
  logModal.style.display = "none";
};
