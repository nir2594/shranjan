/* ================================
   SECTION LOADER (CORE)
================================ */

function loadSection(id, file) {
  const container = document.getElementById(id);
  if (!container) return;

  fetch(`sections/${file}`)
    .then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load ${file}`);
      }
      return res.text();
    })
    .then(html => {
      container.innerHTML = html;
    })
    .catch(err => {
      console.error(err);
    });
}

/* ================================
   LOAD ALL SECTIONS
================================ */

document.addEventListener('DOMContentLoaded', () => {
  loadSection('section-hero', 'hero.html');
  loadSection('section-couple', 'couple.html');
  loadSection('section-events', 'events.html');
  loadSection('section-instagram', 'instagram.html');
  loadSection('section-upload', 'upload.html');
  loadSection('section-gallery', 'gallery.html');
  loadSection('section-video', 'video.html');
  loadSection('section-guestbook', 'guestbook.html');
  loadSection('section-location', 'location.html');
  loadSection('section-footer', 'footer.html');
});