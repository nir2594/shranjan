// assets/js/chat.js

window.toggleChat = () => {
  chatWindow.style.display =
    chatWindow.style.display === "flex" ? "none" : "flex";
};

window.handleKeyPress = (e) => {
  if (e.key === "Enter") sendMessage();
};

window.sendMessage = async () => {
  const text = chatInput.value.trim();
  if (!text) return;

  appendMessage(text, "user");
  chatInput.value = "";

  const reply = await callGeminiAPI(text, "You are a friendly wedding assistant.");
  appendMessage(reply, "bot");
};

function appendMessage(text, type) {
  const div = document.createElement("div");
  div.className = `message ${type}`;
  div.innerText = text;
  chatMessages.appendChild(div);
}
