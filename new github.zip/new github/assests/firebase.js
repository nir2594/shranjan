// assets/js/firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore, collection, addDoc, onSnapshot, query, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

/* ================================
   FIREBASE CONFIG
================================ */

const firebaseConfig = {
  apiKey: "AIzaSyDwzZ10tkDqjkNv9jQRfHClLFHjCxv44RQ",
  authDomain: "shranjan-100c2.firebaseapp.com",
  projectId: "shranjan-100c2",
  storageBucket: "shranjan-100c2.firebasestorage.app",
  messagingSenderId: "733304394682",
  appId: "1:733304394682:web:20d4002581dc6e7dbec383"
};

let app, auth, db, wishesCollection;
let offlineMode = false;
let useInternal = false;
let currentUser = null;

/* ================================
   WISH POOL (SHARED STATE)
================================ */

window.wishPool = [
  { name: "Rahul & Priya", text: "Wishing you a lifetime of love and happiness! ❤️" },
  { name: "Aunt Meena", text: "May your life together be full of love and blessings." },
  { name: "Vikram", text: "Congrats Niranjan! Finally tying the knot! 🕺" }
];

window.updateWishPool = (pool) => {
  window.wishPool = pool;
};

/* ================================
   INIT FIREBASE
================================ */

try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
} catch (e) {
  console.error("Firebase init failed", e);
  offlineMode = true;
}

if (!offlineMode) {
  signInAnonymously(auth);

  onAuthStateChanged(auth, (user) => {
    if (!user) return;

    currentUser = user;
    wishesCollection = collection(db, "guestbook");

    const q = query(wishesCollection, orderBy("timestamp", "desc"));
    onSnapshot(q, (snapshot) => {
      const data = [];
      snapshot.forEach(doc => data.push(doc.data()));
      if (data.length) window.updateWishPool(data);
    });
  });
}

/* ================================
   SAVE WISH (GLOBAL)
================================ */

window.saveWishToFirestore = async (name, relationship, text) => {
  if (!wishesCollection || offlineMode) {
    window.wishPool.unshift({ name, relationship, text });
    return true;
  }

  try {
    await addDoc(wishesCollection, {
      name,
      relationship,
      text,
      timestamp: serverTimestamp()
    });
    return true;
  } catch (e) {
    console.error("Firestore error", e);
    return false;
  }
};
