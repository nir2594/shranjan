// assets/js/ai.js

const apiKey = "AIzaSyBmdCQqpaWeS_urcOQO1zxQmGzc5_M2rNE";

async function callGeminiAPI(userPrompt, systemInstruction) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`;
  const payload = {
    contents: [{ parts: [{ text: userPrompt }] }],
    systemInstruction: { parts: [{ text: systemInstruction }] }
  };

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || "No response.";
  } catch (e) {
    return "AI is currently unavailable.";
  }
}

window.toggleAITools = () => {
  document.getElementById("aiToolsPanel")?.classList.toggle("hidden");
};

window.generateWish = async () => {
  const name = guestName.value;
  const relationship = relationshipSelect.value;
  const tone = wishTone.value;

  const systemPrompt = `You are a friendly Indian wedding guest. Tone: ${tone}. Keep under 40 words.`;
  const userPrompt = `Write a wedding wish for Niranjan and Shraddha from ${name}.`;

  finalWishInput.value = await callGeminiAPI(userPrompt, systemPrompt);
};
